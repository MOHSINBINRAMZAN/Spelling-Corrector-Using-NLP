# Advanced Spelling Corrector

This project implements an advanced spelling corrector that uses probabilistic methods and context-aware corrections to improve text accuracy.

## Features
- Probabilistic spelling correction
- Context-aware corrections using spaCy
- User-defined corrections
- Interactive HTML-based UI

## Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/icodebest/Advanced-Spelling-Corrector.git
   cd spelling_corrector
