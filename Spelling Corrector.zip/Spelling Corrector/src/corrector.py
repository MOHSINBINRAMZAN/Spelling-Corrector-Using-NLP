import re
import collections
import os
import pickle
import string
from collections import Counter
from typing import List, Dict, Set, Optional
import numpy as np
from difflib import SequenceMatcher

try:
    import spacy
    SPACY_AVAILABLE = True
except ImportError:
    SPACY_AVAILABLE = False
    print("Spacy not available. Context-based corrections will be limited.")

class SpellingCorrector:
    def __init__(self, corpus_file=None, user_dict_file=None, context_aware=True):
        self.WORDS = Counter()
        self.total_words = 0
        self.user_corrections = {}
        self.user_dict_file = user_dict_file or "models/user_corrections.pkl"
        self.context_aware = context_aware
        
        self._load_user_dict()
        
        if corpus_file:
            self.train(corpus_file)
        
        self.nlp = None
        if SPACY_AVAILABLE and context_aware:
            try:
                self.nlp = spacy.load("en_core_web_md")
                print("Loaded spaCy model for context-aware corrections")
            except:
                print("Could not load spaCy model. Please install with: python -m spacy download en_core_web_md")
        
        self.phonetic_patterns = {
            'f': ['ph'], 'ph': ['f'],
            'ite': ['ight'], 'ight': ['ite'],
            'sh': ['ti', 'ci'], 'ti': ['sh'], 'ci': ['sh'],
            'c': ['k', 's'], 'k': ['c', 'ck'], 's': ['c'],
            'j': ['g', 'dg'], 'g': ['j'], 'dg': ['j'],
            'w': ['wh'], 'wh': ['w'],
            'z': ['s'], 's': ['z'],
            'er': ['or', 'ur'], 'or': ['er'], 'ur': ['er'],
            'ou': ['ow'], 'ow': ['ou'],
            'ai': ['ay'], 'ay': ['ai'],
            'ie': ['ei'], 'ei': ['ie'],
        }
        
        self.correction_cache = {}
        
        self.common_affixes = {
            'prefixes': ['re', 'un', 'in', 'im', 'dis', 'en', 'em', 'non', 'de', 'over', 'mis', 'sub', 'pre', 'inter', 'fore', 'anti', 'auto', 'bi', 'co', 'ex', 'mid', 'semi'],
            'suffixes': ['ing', 'ed', 'er', 'ers', 'or', 'ion', 'ions', 'tion', 'ations', 'ition', 'ician', 'ance', 'ence', 'ment', 'ness', 'ity', 'ty', 'ies', 's', 'es', 'ism', 'able', 'ible', 'al', 'ial', 'ical', 'ful', 'ous', 'ious', 'eous', 'ious', 'less', 'ive']
        }

    def _load_user_dict(self):
        if os.path.exists(self.user_dict_file):
            try:
                with open(self.user_dict_file, 'rb') as f:
                    self.user_corrections = pickle.load(f)
                print(f"Loaded {len(self.user_corrections)} user corrections")
            except Exception as e:
                print(f"Error loading user dictionary: {e}")
                self.user_corrections = {}

    def _save_user_dict(self):
        try:
            with open(self.user_dict_file, 'wb') as f:
                pickle.dump(self.user_corrections, f)
        except Exception as e:
            print(f"Error saving user dictionary: {e}")

    def train(self, corpus_file):
        try:
            with open(corpus_file, 'r', encoding='utf-8') as f:
                words = re.findall(r'\w+', f.read().lower())
                self.WORDS.update(words)
                self.total_words = sum(self.WORDS.values())
            print(f"Trained on {len(self.WORDS)} unique words from corpus")
        except Exception as e:
            print(f"Error training on corpus: {e}")
            
    def train_on_text(self, text):
        words = re.findall(r'\w+', text.lower())
        self.WORDS.update(words)
        self.total_words = sum(self.WORDS.values())
        return len(words)

    def P(self, word):
        return self.WORDS[word] / self.total_words if self.total_words > 0 else 0

    def edits1(self, word):
        letters = string.ascii_lowercase
        splits = [(word[:i], word[i:]) for i in range(len(word) + 1)]
        
        deletes = [L + R[1:] for L, R in splits if R]
        transposes = [L + R[1] + R[0] + R[2:] for L, R in splits if len(R) > 1]
        replaces = [L + c + R[1:] for L, R in splits if R for c in letters]
        inserts = [L + c + R for L, R in splits for c in letters]
        
        phonetic_edits = []
        for L, R in splits:
            for i in range(1, min(5, len(R) + 1)):
                if R[:i] in self.phonetic_patterns:
                    for alternative in self.phonetic_patterns[R[:i]]:
                        phonetic_edits.append(L + alternative + R[i:])
                        
        affix_edits = []
        
        for prefix in self.common_affixes['prefixes']:
            if word.startswith(prefix):
                affix_edits.append(word[len(prefix):])
            else:
                affix_edits.append(prefix + word)
                
        for suffix in self.common_affixes['suffixes']:
            if word.endswith(suffix):
                affix_edits.append(word[:-len(suffix)])
            else:
                if len(word) > 3:
                    if suffix.startswith('i') and word.endswith('y'):
                        affix_edits.append(word[:-1] + suffix)
                    elif suffix.startswith('e') and word.endswith('e'):
                        affix_edits.append(word[:-1] + suffix)
                    else:
                        affix_edits.append(word + suffix)
        
        all_edits = set(deletes + transposes + replaces + inserts + phonetic_edits + affix_edits)
        return all_edits

    def edits2(self, word):
        return (e2 for e1 in self.edits1(word) for e2 in self.edits1(e1))

    def known(self, words):
        return set(w for w in words if w in self.WORDS or w in self.user_corrections)

    def candidates(self, word):
        if word in self.correction_cache:
            return self.correction_cache[word]
            
        if word in self.user_corrections:
            return [self.user_corrections[word]]
            
        candidates = (
            self.known([word]) or 
            self.known(self.edits1(word)) or 
            self.known(self.edits2(word)) or 
            [word]
        )
        
        if len(word) > 5 and word not in candidates:
            candidates.add(word)
            
        self.correction_cache[word] = list(candidates)
        return list(candidates)

    def rank_candidates(self, candidates, word, context=None):
        word_scores = []
        
        for candidate in candidates:
            score = self.P(candidate)
            
            if candidate == word:
                score *= 2.0
                
            if word in self.user_corrections and candidate == self.user_corrections[word]:
                score *= 10.0
                
            similarity = SequenceMatcher(None, word, candidate).ratio()
            score *= (0.5 + 0.5 * similarity)
            
            len_diff = abs(len(candidate) - len(word))
            length_penalty = max(0.5, 1.0 - (len_diff / 10.0))
            score *= length_penalty
            
            if context and self.nlp:
                try:
                    context_score = self._context_score(candidate, context)
                    score *= (1.0 + context_score)
                except Exception as e:
                    print(f"Error computing context score: {e}")
            
            word_scores.append((candidate, score))
        
        return sorted(word_scores, key=lambda x: x[1], reverse=True)

    def _context_score(self, word, context):
        if not self.nlp:
            return 0
            
        try:
            context_doc = self.nlp(" ".join(context))
            word_vector = self.nlp(word).vector
            
            similarities = []
            for token in context_doc:
                if token.has_vector and token.text.lower() != word.lower():
                    sim = token.vector.dot(word_vector) / (np.linalg.norm(token.vector) * np.linalg.norm(word_vector))
                    similarities.append(sim)
            
            return np.mean(similarities) if similarities else 0
        except Exception as e:
            print(f"Error in context scoring: {e}")
            return 0

    def correct_word(self, word, context=None):
        if len(word) <= 1 or word.isdigit() or (word.isupper() and len(word) > 1):
            return word
            
        if word[0].isupper() and len(word) > 1 and not all(w.isupper() for w in word):
            if context and context.index(word) > 0:
                return word
        
        candidates = self.candidates(word.lower())
        
        if word.lower() in self.WORDS and candidates[0] == word.lower():
            return word
            
        ranked = self.rank_candidates(candidates, word.lower(), context)
        
        correction = ranked[0][0] if ranked else word.lower()
        
        if word.istitle():
            correction = correction.title()
        elif word.isupper():
            correction = correction.upper()
            
        return correction

    def correct_text(self, text):
        result = []
        corrections = {}
        text_blocks = []
        
        paragraphs = text.split('\n')
        
        for paragraph in paragraphs:
            tokens = []
            current_pos = 0
            for match in re.finditer(r'\w+|\s+|[^\w\s]', paragraph):
                token = match.group(0)
                start_pos = match.start()
                
                if start_pos > current_pos:
                    tokens.append(paragraph[current_pos:start_pos])
                    
                tokens.append(token)
                current_pos = match.end()
            
            processed_tokens = []
            words_only = [t for t in tokens if re.match(r'^\w+$', t)]
            
            for token in tokens:
                if re.match(r'^\w+$', token):
                    token_idx = words_only.index(token)
                    start_idx = max(0, token_idx - 3)
                    end_idx = min(len(words_only), token_idx + 4)
                    context = words_only[start_idx:end_idx]
                    
                    correction = self.correct_word(token, context)
                    
                    if correction.lower() != token.lower():
                        corrections[token] = correction
                        
                    processed_tokens.append(correction)
                else:
                    processed_tokens.append(token)
            
            text_blocks.append(''.join(processed_tokens))
        
        corrected_text = '\n'.join(text_blocks)
        
        return {
            'corrected_text': corrected_text,
            'corrections': corrections
        }

    def suggest_corrections(self, word, max_suggestions=5, context=None):
        candidates = self.candidates(word.lower())
        ranked = self.rank_candidates(candidates, word.lower(), context)
        
        top_suggestions = ranked[:max_suggestions]
        
        total_score = sum(score for _, score in top_suggestions)
        if total_score > 0:
            normalized = [(candidate, score/total_score) for candidate, score in top_suggestions]
        else:
            normalized = [(candidate, 1.0 if i == 0 else 0.0) for i, (candidate, _) in enumerate(top_suggestions)]
            
        return normalized

    def learn_correction(self, misspelled, correction):
        self.user_corrections[misspelled.lower()] = correction.lower()
        
        self.WORDS[correction.lower()] += max(1, int(self.total_words * 0.0001))
        self.total_words = sum(self.WORDS.values())
        
        if misspelled in self.correction_cache:
            del self.correction_cache[misspelled]
            
        self._save_user_dict()

    def batch_process(self, document_path, output_path=None):
        try:
            with open(document_path, 'r', encoding='utf-8') as f:
                text = f.read()
                
            result = self.correct_text(text)
            
            if output_path:
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(result['corrected_text'])
                    
                log_path = output_path + '.corrections.txt'
                with open(log_path, 'w', encoding='utf-8') as f:
                    f.write("CORRECTIONS LOG\n")
                    f.write("===============\n\n")
                    for original, correction in result['corrections'].items():
                        f.write(f"{original} -> {correction}\n")
                        
                return {
                    'success': True,
                    'corrections_count': len(result['corrections']),
                    'output_path': output_path,
                    'log_path': log_path
                }
            else:
                return {
                    'success': True,
                    'corrected_text': result['corrected_text'],
                    'corrections': result['corrections']
                }
                
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }


