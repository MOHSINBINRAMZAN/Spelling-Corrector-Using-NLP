from flask import Flask, render_template_string, request, jsonify
from corrector import SpellingCorrector
from context_aware import ContextAwareCorrector
from ui import SpellingCorrectorUI
import os

app = Flask(__name__)

# Initialize the corrector
def create_spelling_corrector():
    base_corrector = SpellingCorrector(corpus_file="data/big.txt", context_aware=True)
    context_corrector = ContextAwareCorrector(base_corrector)
    return context_corrector

corrector = create_spelling_corrector()
ui = SpellingCorrectorUI(corrector)

@app.route('/')
def home():
    # Serve the HTML interface
    html = ui.get_html_interface()
    return render_template_string(html)

@app.route('/correct', methods=['POST'])
def correct_text():
    data = request.json
    result = ui.process_correction_request(data)
    return jsonify(result)

@app.route('/suggest', methods=['POST'])
def suggest_corrections():
    data = request.json
    result = ui.process_suggestion_request(data)
    return jsonify(result)

@app.route('/learn', methods=['POST'])
def learn_correction():
    data = request.json
    result = ui.process_learn_request(data)
    return jsonify(result)

if __name__ == '__main__':
    # Ensure the data directory exists
    if not os.path.exists("data"):
        os.makedirs("data")
    
    # Download the dataset if not already present
    if not os.path.exists("data/big.txt"):
        print("Downloading dataset...")
        url = "http://norvig.com/big.txt"
        response = requests.get(url)
        if response.status_code == 200:
            with open("data/big.txt", "wb") as file:
                file.write(response.content)
            print("Dataset downloaded successfully!")
        else:
            print("Failed to download dataset.")
    
    # Run the Flask app
    app.run(debug=True)