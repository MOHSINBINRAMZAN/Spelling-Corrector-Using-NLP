class SpellingCorrectorUI:
    def __init__(self, corrector):
        self.corrector = corrector
        self.current_text = ""
        self.current_corrections = {}
        self.suggestion_position = None
        
    def get_html_interface(self):
        html = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Advanced Spelling Corrector</title>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 1000px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #f7f9fc;
                }
                
                h1 {
                    color: #2c3e50;
                    text-align: center;
                    margin-bottom: 30px;
                }
                
                .container {
                    display: flex;
                    gap: 20px;
                    flex-wrap: wrap;
                }
                
                .editor-section, .corrections-section {
                    flex: 1;
                    min-width: 300px;
                    background: white;
                    padding: 20px;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }
                
                .editor-wrapper {
                    position: relative;
                    margin-bottom: 15px;
                }
                
                #editor {
                    width: 100%;
                    min-height: 300px;
                    padding: 15px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 16px;
                    line-height: 1.5;
                    resize: vertical;
                    background-color: #fff;
                    box-sizing: border-box;
                    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
                }
                
                .suggestions-popup {
                    position: absolute;
                    background: white;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
                    max-width: 300px;
                    display: none;
                    z-index: 100;
                }
                
                .suggestion-item {
                    padding: 8px 12px;
                    cursor: pointer;
                    border-bottom: 1px solid #eee;
                }
                
                .suggestion-item:hover {
                    background-color: #f0f7ff;
                }
                
                .confidence {
                    float: right;
                    color: #777;
                    font-size: 0.8em;
                }
                
                .button-row {
                    display: flex;
                    gap: 10px;
                    margin-bottom: 20px;
                }
                
                button {
                    background-color: #4285f4;
                    color: white;
                    border: none;
                    padding: 10px 15px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    transition: background-color 0.2s;
                }
                
                button:hover {
                    background-color: #3367d6;
                }
                
                .corrections-list {
                    max-height: 300px;
                    overflow-y: auto;
                    border: 1px solid #eee;
                    border-radius: 4px;
                    padding: 10px;
                }
                
                .correction-item {
                    padding: 8px;
                    margin-bottom: 5px;
                    border-bottom: 1px solid #f0f0f0;
                }
                
                .correction-original {
                    text-decoration: line-through;
                    color: #e74c3c;
                }
                
                .correction-fixed {
                    font-weight: bold;
                    color: #27ae60;
                }
                
                .highlight-error {
                    text-decoration: underline wavy #e74c3c;
                }
                
                .section-title {
                    font-weight: 600;
                    margin-bottom: 15px;
                    color: #2c3e50;
                }
                
                .stats {
                    margin-top: 15px;
                    font-size: 14px;
                    color: #555;
                }
                
                .toggle-container {
                    display: flex;
                    align-items: center;
                    margin-bottom: 15px;
                }
                
                .toggle-switch {
                    position: relative;
                    display: inline-block;
                    width: 50px;
                    height: 24px;
                    margin-right: 10px;
                }
                
                .toggle-switch input {
                    opacity: 0;
                    width: 0;
                    height: 0;
                }
                
                .toggle-slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: #ccc;
                    transition: .4s;
                    border-radius: 24px;
                }
                
                .toggle-slider:before {
                    position: absolute;
                    content: "";
                    height: 16px;
                    width: 16px;
                    left: 4px;
                    bottom: 4px;
                    background-color: white;
                    transition: .4s;
                    border-radius: 50%;
                }
                
                input:checked + .toggle-slider {
                    background-color: #4285f4;
                }
                
                input:checked + .toggle-slider:before {
                    transform: translateX(26px);
                }
                
                @media (max-width: 768px) {
                    .container {
                        flex-direction: column;
                    }
                    
                    .editor-section, .corrections-section {
                        width: 100%;
                    }
                }
            </style>
        </head>
        <body>
            <h1>Advanced Spelling Corrector</h1>
            
            <div class="container">
                <div class="editor-section">
                    <div class="section-title">Text Editor</div>
                    
                    <div class="toggle-container">
                        <label class="toggle-switch">
                            <input type="checkbox" id="auto-correct-toggle" checked>
                            <span class="toggle-slider"></span>
                        </label>
                        <span>Auto-suggest corrections</span>
                    </div>
                    
                    <div class="editor-wrapper">
                        <textarea id="editor" placeholder="Type or paste your text here..."></textarea>
                        <div id="suggestions-popup" class="suggestions-popup"></div>
                    </div>
                    
                    <div class="button-row">
                        <button id="correct-button">Correct Text</button>
                        <button id="clear-button">Clear Text</button>
                        <button id="learn-button">Learn Custom Words</button>
                    </div>
                </div>
                
                <div class="corrections-section">
                    <div class="section-title">Corrections</div>
                    <div id="corrections-list" class="corrections-list">
                        <div class="correction-item">No corrections yet. Type some text and click "Correct Text".</div>
                    </div>
                    
                    <div class="stats" id="stats">
                        Words processed: 0 | Corrections made: 0
                    </div>
                </div>
            </div>
            
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const editor = document.getElementById('editor');
                    const suggestionsPopup = document.getElementById('suggestions-popup');
                    const correctButton = document.getElementById('correct-button');
                    const clearButton = document.getElementById('clear-button');
                    const learnButton = document.getElementById('learn-button');
                    const correctionsList = document.getElementById('corrections-list');
                    const stats = document.getElementById('stats');
                    const autoCorrectToggle = document.getElementById('auto-correct-toggle');
                    
                    let typingTimer;
                    const doneTypingInterval = 500; // ms
                    let currentCorrections = {};
                    let cursorPosition = 0;
                    
                    editor.addEventListener('click', function() {
                        cursorPosition = this.selectionStart;
                    });
                    
                    editor.addEventListener('keyup', function(e) {
                        cursorPosition = this.selectionStart;
                        
                        if ([37, 38, 39, 40].includes(e.keyCode)) return;
                        
                        clearTimeout(typingTimer);
                        
                        if (autoCorrectToggle.checked) {
                            typingTimer = setTimeout(() => {
                                const text = editor.value;
                                const wordBreakAfter = /\\s|\\.|,|;|:|\\!|\\?|\\)|\\]|\\}|$/.test(text.charAt(cursorPosition));
                                const wordBreakBefore = /\\s|\\.|,|;|:|\\!|\\?|\\(|\\[|\\{|^/.test(text.charAt(cursorPosition - 1));
                                
                                if (wordBreakAfter && !wordBreakBefore) {
                                    getSuggestions(text, cursorPosition);
                                } else {
                                    suggestionsPopup.style.display = 'none';
                                }
                            }, doneTypingInterval);
                        }
                    });
                    
                    function getSuggestions(text, position) {
                        findWordAtPosition(text, position).then(result => {
                            if (result && result.suggestions && result.suggestions.length > 0) {
                                displaySuggestions(result.word, result.suggestions, position);
                            } else {
                                suggestionsPopup.style.display = 'none';
                            }
                        });
                    }
                    
                    function findWordAtPosition(text, position) {
                        return fetch('/suggest', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({ text: text, position: position }),
                        }).then(response => response.json());
                    }
                    
                    function displaySuggestions(word, suggestions, position) {
                        const editorRect = editor.getBoundingClientRect();
                        const wordStart = editor.value.lastIndexOf(word, position);
                        
                        if (wordStart === -1) {
                            suggestionsPopup.style.display = 'none';
                            return;
                        }
                        
                        const textUpToWord = editor.value.substring(0, wordStart);
                        const lines = textUpToWord.split('\\n');
                        const lineCount = lines.length;
                        const lastLine = lines[lines.length - 1];
                        
                        const temp = document.createElement('div');
                        temp.style.position = 'absolute';
                        temp.style.visibility = 'hidden';
                        temp.style.whiteSpace = 'pre';
                        temp.style.font = getComputedStyle(editor).font;
                        temp.textContent = lastLine;
                        document.body.appendChild(temp);
                        
                        const offsetX = temp.getBoundingClientRect().width;
                        document.body.removeChild(temp);
                        
                        const lineHeight = parseInt(getComputedStyle(editor).lineHeight);
                        const offsetY = (lineCount - 1) * lineHeight;
                        
                        suggestionsPopup.innerHTML = '';
                        
                        suggestions.forEach(([suggestion, confidence]) => {
                            const item = document.createElement('div');
                            item.className = 'suggestion-item';
                            
                            const suggestionText = document.createElement('span');
                            suggestionText.textContent = suggestion;
                            
                            const confidenceSpan = document.createElement('span');
                            confidenceSpan.className = 'confidence';
                            confidenceSpan.textContent = Math.round(confidence * 100) + '%';
                            
                            item.appendChild(suggestionText);
                            item.appendChild(confidenceSpan);
                            
                            item.addEventListener('click', function() {
                                applySuggestion(word, suggestion);
                            });
                            
                            suggestionsPopup.appendChild(item);
                        });
                        
                        suggestionsPopup.style.left = `${offsetX + 20}px`;
                        suggestionsPopup.style.top = `${offsetY + 40}px`;
                        suggestionsPopup.style.display = 'block';
                    }
                    
                    function applySuggestion(original, replacement) {
                        const text = editor.value;
                        const sel = editor.selectionStart;
                        
                        const wordStart = text.lastIndexOf(original, sel);
                        if (wordStart !== -1) {
                            const before = text.substring(0, wordStart);
                            const after = text.substring(wordStart + original.length);
                            
                            editor.value = before + replacement + after;
                            
                            const newPosition = wordStart + replacement.length;
                            editor.setSelectionRange(newPosition, newPosition);
                            editor.focus();
                            
                            suggestionsPopup.style.display = 'none';
                            
                            addToCorrections(original, replacement);
                        }
                    }
                    
                    function addToCorrections(original, corrected) {
                        if (original.toLowerCase() === corrected.toLowerCase()) return;
                        
                        currentCorrections[original] = corrected;
                        updateCorrectionsList();
                    }
                    
                    function updateCorrectionsList() {
                        correctionsList.innerHTML = '';
                        
                        const entries = Object.entries(currentCorrections);
                        if (entries.length === 0) {
                            correctionsList.innerHTML = '<div class="correction-item">No corrections made yet.</div>';
                            return;
                        }
                        
                        entries.forEach(([original, corrected]) => {
                            const item = document.createElement('div');
                            item.className = 'correction-item';
                            
                            const originalSpan = document.createElement('span');
                            originalSpan.className = 'correction-original';
                            originalSpan.textContent = original;
                            
                            const arrow = document.createTextNode(' → ');
                            
                            const correctedSpan = document.createElement('span');
                            correctedSpan.className = 'correction-fixed';
                            correctedSpan.textContent = corrected;
                            
                            item.appendChild(originalSpan);
                            item.appendChild(arrow);
                            item.appendChild(correctedSpan);
                            
                            correctionsList.appendChild(item);
                        });
                        
                        const wordCount = editor.value.split(/\\s+/).filter(w => w.length > 0).length;
                        stats.textContent = `Words processed: ${wordCount} | Corrections made: ${entries.length}`;
                    }
                    
                    correctButton.addEventListener('click', function() {
                        const text = editor.value;
                        if (!text.trim()) return;
                        
                        correctText(text).then(result => {
                            if (result && result.corrected_text) {
                                editor.value = result.corrected_text;
                                currentCorrections = result.corrections || {};
                                updateCorrectionsList();
                            }
                        });
                    });
                    
                    function correctText(text) {
                        return fetch('/correct', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({ text: text }),
                        }).then(response => response.json());
                    }
                    
                    clearButton.addEventListener('click', function() {
                        editor.value = '';
                        currentCorrections = {};
                        updateCorrectionsList();
                    });
                    
                    learnButton.addEventListener('click', function() {
                        const customWord = prompt('Enter a custom word to add to dictionary:');
                        if (customWord && customWord.trim()) {
                            learnCustomWord(customWord.trim()).then(result => {
                                if (result && result.success) {
                                    alert(`Added "${customWord}" to dictionary`);
                                }
                            });
                        }
                    });
                    
                    function learnCustomWord(word) {
                        return fetch('/learn', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({ misspelled: word, correction: word }),
                        }).then(response => response.json());
                    }
                });
            </script>
        </body>
        </html>
        """
        return html

    def process_correction_request(self, request):
        text = request.get("text", "")
        if not text:
            return {"error": "No text provided"}
            
        result = self.corrector.correct_text(text)
        self.current_text = result["corrected_text"]
        self.current_corrections = result["corrections"]
        
        return result
        
    def process_suggestion_request(self, request):
        text = request.get("text", "")
        position = request.get("position", 0)
        
        if not text:
            return {"error": "No text provided"}
            
        result = self.corrector.suggest_alternatives(text, position)
        return result
        
    def process_learn_request(self, request):
        misspelled = request.get("misspelled", "")
        correction = request.get("correction", "")
        
        if not misspelled or not correction:
            return {"error": "Both misspelled and correction must be provided"}
            
        self.corrector.learn_correction(misspelled, correction)
        return {"success": True}