import re

class ContextAwareCorrector:
    def __init__(self, base_corrector):
        self.base_corrector = base_corrector
        self.grammar_patterns = [
            (r'\b(a)\s+([aeiou]\w+)', r'an \2'),
            (r'\b(an)\s+([^aeiou]\w+)', r'a \2'),
            (r'\b(your)\s+(going|doing)\b', r'you\'re \2'),
            (r'\b(their)\s+(going|doing)\b', r'they\'re \2'),
            (r'\b(its)\s+(going|doing)\b', r'it\'s \2'),
            (r'\b(there)\s+(car|house|dog|cat|book|phone)\b', r'their \2'),
            (r'\b(their)\s+(is|are|was|were)\b', r'there \2'),
            (r'\b(your)\s+(welcome)\b', r'you\'re \2'),
            (r'\b(of)\s+(been)\b', r'have \2'),
            (r'\b(would|should|could)\s+(of)\b', r'\1 have'),
            (r'\b(wont)\b', r'won\'t'),
            (r'\b(cant)\b', r'can\'t'),
            (r'\b(dont)\b', r'don\'t'),
            (r'\b(didnt)\b', r'didn\'t'),
            (r'\b(wouldnt)\b', r'wouldn\'t'),
            (r'\b(shouldnt)\b', r'shouldn\'t'),
            (r'\b(couldnt)\b', r'couldn\'t'),
            (r'\b(isnt)\b', r'isn\'t'),
            (r'\b(arent)\b', r'aren\'t'),
            (r'\b(werent)\b', r'weren\'t'),
            (r'\b(wasnt)\b', r'wasn\'t'),
            (r'\b(havent)\b', r'haven\'t'),
            (r'\b(hasnt)\b', r'hasn\'t'),
            (r'\b(hadnt)\b', r'hadn\'t'),
        ]

    def correct_text(self, text):
        base_result = self.base_corrector.correct_text(text)
        corrected_text = base_result['corrected_text']
        
        for pattern, replacement in self.grammar_patterns:
            corrected_text = re.sub(pattern, replacement, corrected_text, flags=re.IGNORECASE)
        
        grammar_corrections = {}
        for pattern, replacement in self.grammar_patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                original = match.group(0)
                fixed = re.sub(pattern, replacement, original, flags=re.IGNORECASE)
                if original.lower() != fixed.lower():
                    grammar_corrections[original] = fixed
        
        all_corrections = {**base_result['corrections'], **grammar_corrections}
        
        return {
            'corrected_text': corrected_text,
            'corrections': all_corrections
        }

    def suggest_alternatives(self, text, position):
        words = re.finditer(r'\w+', text)
        target_word = None
        context = []
        
        for match in words:
            start, end = match.span()
            if start <= position < end:
                target_word = match.group(0)
                position_in_word = position - start
                break
                
        if not target_word:
            return []
            
        words_list = re.findall(r'\w+', text)
        if target_word in words_list:
            target_idx = words_list.index(target_word)
            start_idx = max(0, target_idx - 3)
            end_idx = min(len(words_list), target_idx + 4)
            context = words_list[start_idx:end_idx]
            
        suggestions = self.base_corrector.suggest_corrections(target_word, max_suggestions=5, context=context)
        
        return {
            'word': target_word,
            'suggestions': suggestions,
            'context': context
        }