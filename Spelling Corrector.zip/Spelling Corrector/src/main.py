import requests
from corrector import SpellingCorrector
from context_aware import ContextAwareCorrector
from ui import SpellingCorrectorUI

def download_dataset():
    url = "http://norvig.com/big.txt"
    response = requests.get(url)
    if response.status_code == 200:
        with open("data/big.txt", "wb") as file:
            file.write(response.content)
        print("big.txt downloaded successfully!")
    else:
        print("Failed to download big.txt")

def create_spelling_corrector(corpus_file="data/big.txt"):
    base_corrector = SpellingCorrector(corpus_file=corpus_file, context_aware=True)
    context_corrector = ContextAwareCorrector(base_corrector)
    return context_corrector

def main():
    print("Initializing Advanced Spelling Corrector...")
    
    # Download dataset if not already present
    if not os.path.exists("data/big.txt"):
        download_dataset()
    
    # Create corrector
    corrector = create_spelling_corrector()
    
    # Create UI
    ui = SpellingCorrectorUI(corrector)
    
    # Example correction
    example_text = "okay i wull bee thare fr you my lovve"
    
    print("\n=== Example Correction ===")
    print("Original text:")
    print(example_text)
    
    result = corrector.correct_text(example_text)
    
    print("\nCorrected text:")
    print(result["corrected_text"])
    
    print("\nCorrections made:")
    for original, correction in result["corrections"].items():
        print(f"  {original} -> {correction}")
    
    # Show suggestions for a misspelled word
    misspelled = "expreiment"
    suggestions = corrector.base_corrector.suggest_corrections(misspelled, max_suggestions=3)
    
    print("\n=== Suggestions for '{}' ===".format(misspelled))
    for suggestion, confidence in suggestions:
        print(f"  {suggestion} ({confidence:.2f})")
    
    # If running in an environment with HTML support
    print("\nHTML interface is available through the UI object")
    
    return {
        "corrector": corrector,
        "ui": ui,
        "example_result": result
    }

if __name__ == "__main__":
    main() 